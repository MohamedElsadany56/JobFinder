function showResetPage() {
    document.getElementById('login-page').style.display = 'none';
    document.getElementById('reset-page').style.display = 'block';
}

function showLoginPage() {
    document.getElementById('reset-page').style.display = 'none';
    document.getElementById('login-page').style.display = 'block';
}

function login() {
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    if (email && password) {
        alert(`Logged in as ${email}`);
    } else {
        alert('Please fill out all fields.');
    }
}

function resetPassword() {
    const resetEmail = document.getElementById('reset-email').value;

    if (resetEmail) {
        alert(`Password reset link sent to ${resetEmail}`);
    } else {
        alert('Please enter your email.');
    }
}
